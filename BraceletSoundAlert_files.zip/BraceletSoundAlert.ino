/*
  دستبند هشداردهنده ناشنوایان — نمونه اولیه
  برد: ESP32-C3 SuperMini
  میکروفون: INMP441 (I2S)

  سیم‌کشی میکروفون:
    INMP441 VDD -> 3V3
    INMP441 GND -> GND
    INMP441 SCK -> GPIO4
    INMP441 WS  -> GPIO5
    INMP441 SD  -> GPIO6
    INMP441 L/R -> GND

  خروجی آزمایشی:
    GPIO7 -> ورودی درایور MOSFET موتور ویبره
    GND برد -> GND درایور
    موتور را مستقیم به GPIO وصل نکنید.

  مهم:
  این نسخه فقط صدای نسبتاً بلند را با یک معیار ساده تشخیص می‌دهد و
  الگوی لرزش/LED را فعال می‌کند. این نسخه هنوز نمی‌تواند به‌طور قابل
  اعتماد زنگ در، بوق خودرو و آژیر را از هم تشخیص دهد. برای آن باید
  الگوریتم/مدل تشخیص صدا و آزمایش‌های بیشتری اضافه شود.
*/

#include <Arduino.h>
#include "driver/i2s.h"
#include <math.h>

// پین‌های پیشنهادی؛ قبل از اتصال با نوشته‌های روی برد خود تطبیق دهید.
static const int PIN_I2S_BCLK = 4;  // INMP441 SCK
static const int PIN_I2S_WS   = 5;  // INMP441 WS
static const int PIN_I2S_DIN  = 6;  // INMP441 SD
static const int PIN_MOTOR    = 7;  // ورودی درایور موتور، نه خود موتور
static const int PIN_LED      = 8;  // LED با مقاومت سری؛ اگر GPIO8 در برد شما در دسترس/آزاد نیست، تغییر دهید

static const i2s_port_t I2S_PORT = I2S_NUM_0;
static const uint32_t SAMPLE_RATE = 16000;
static const size_t SAMPLE_COUNT = 512;

// آستانه اولیه و قابل تنظیم است؛ محیط واقعی نیاز به کالیبراسیون دارد.
static const float SOUND_THRESHOLD = 180.0f;
static const unsigned long COOLDOWN_MS = 2500;

int32_t samples[SAMPLE_COUNT];
unsigned long lastAlertMs = 0;

void setupI2SMicrophone() {
  i2s_config_t config = {};
  config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  config.sample_rate = SAMPLE_RATE;
  config.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
  config.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  config.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  config.dma_buf_count = 4;
  config.dma_buf_len = 256;
  config.use_apll = false;
  config.tx_desc_auto_clear = false;
  config.fixed_mclk = 0;

  i2s_pin_config_t pinConfig = {};
  pinConfig.bck_io_num = PIN_I2S_BCLK;
  pinConfig.ws_io_num = PIN_I2S_WS;
  pinConfig.data_out_num = I2S_PIN_NO_CHANGE;
  pinConfig.data_in_num = PIN_I2S_DIN;

  esp_err_t err = i2s_driver_install(I2S_PORT, &config, 0, nullptr);
  if (err != ESP_OK) {
    Serial.printf("I2S driver install failed: %d\n", (int)err);
    while (true) delay(1000);
  }

  err = i2s_set_pin(I2S_PORT, &pinConfig);
  if (err != ESP_OK) {
    Serial.printf("I2S pin setup failed: %d\n", (int)err);
    while (true) delay(1000);
  }

  i2s_zero_dma_buffer(I2S_PORT);
}

float readSoundLevel() {
  size_t bytesRead = 0;
  esp_err_t err = i2s_read(
    I2S_PORT,
    (void*)samples,
    sizeof(samples),
    &bytesRead,
    portMAX_DELAY
  );

  if (err != ESP_OK || bytesRead < sizeof(int32_t) * 8) {
    return 0.0f;
  }

  const size_t count = bytesRead / sizeof(int32_t);
  double sumSquares = 0.0;
  double mean = 0.0;

  // INMP441 معمولاً نمونه 24 بیتی را داخل کلمه 32 بیتی می‌دهد.
  // شیفت 14 بیتی یک مقیاس عملی اولیه است و ممکن است بسته به ماژول نیاز به تنظیم داشته باشد.
  for (size_t i = 0; i < count; i++) {
    int32_t s = samples[i] >> 14;
    mean += s;
  }
  mean /= count;

  for (size_t i = 0; i < count; i++) {
    double s = (double)(samples[i] >> 14) - mean;
    sumSquares += s * s;
  }

  return (float)sqrt(sumSquares / count);
}

void vibratePattern(unsigned int pulses, unsigned int onMs, unsigned int offMs) {
  for (unsigned int i = 0; i < pulses; i++) {
    digitalWrite(PIN_MOTOR, HIGH);
    digitalWrite(PIN_LED, HIGH);
    delay(onMs);
    digitalWrite(PIN_MOTOR, LOW);
    digitalWrite(PIN_LED, LOW);
    if (i + 1 < pulses) delay(offMs);
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(PIN_MOTOR, OUTPUT);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_MOTOR, LOW);
  digitalWrite(PIN_LED, LOW);

  setupI2SMicrophone();
  Serial.println("دستبند هشداردهنده آماده است.");
  Serial.println("Serial Monitor را روی 115200 قرار دهید.");
}

void loop() {
  float level = readSoundLevel();
  Serial.printf("Sound level: %.1f\n", level);

  unsigned long now = millis();
  if (level > SOUND_THRESHOLD && now - lastAlertMs > COOLDOWN_MS) {
    lastAlertMs = now;

    // هشدار عمومی برای صدای بلند؛ هنوز تشخیص نوع صدا نیست.
    vibratePattern(2, 180, 140);
  }
}
